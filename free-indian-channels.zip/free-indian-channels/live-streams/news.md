# 📰 News Channel Streams (India)

These are **legal** and publicly available streams.

- [DD News](https://www.youtube.com/c/DDNewsOfficial/live)
- [Sansad TV Lok Sabha](https://www.youtube.com/c/loksabhatv/live)
- [Sansad TV Rajya Sabha](https://www.youtube.com/c/rajyasabhatv/live)
- [News18 India](https://www.youtube.com/c/News18India/live)

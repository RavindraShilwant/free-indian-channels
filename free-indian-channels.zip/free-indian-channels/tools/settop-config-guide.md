# 📺 Set-Top Box Manual Tuning Guide

## DD Free Dish (Generic Set-Top Box)
1. Go to Menu > Installation > Manual Scan
2. Satellite: GSAT-15 @ 93.5°E
3. Frequency: 11090
4. Symbol Rate: 29500
5. Polarization: Vertical
6. Search Type: FTA Only
7. Press OK to scan

## Airtel DTH (Manual)
Coming soon...

## Tata Play
Tata Play boxes are locked. FTA channels via Tata Play require subscription or official access.
